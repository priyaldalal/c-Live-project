﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace INMS.BAL
{
    public class BAL_CAT
    {
        public string ACTION { get; set; }
          public int CID { get; set; }
        public string CNAME { get; set; }

        public int BID { get; set; }
        public string BNAME { get; set; }
        public string BDISCRIPTION { get; set; }
      
    }
}