﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace INMS.BAL
{
    public class BAL_PRODUCT
    {
        public string ACTION { get; set; }
        public int PID { get; set; }
        public string PNAME { get; set; }
        public string DISCRIPTION { get; set; }
        public string CATEGORY { get; set; }

        public string BRAND { get; set; }
        public string STATUS { get; set; }
        public int COST { get; set; }
        public string DATE { get; set; }

        public int CID { get; set; }
        public string CNAME { get; set; }

        public int BID { get; set; }
        public string BNAME { get; set; }
        public string BDISCRIPTION { get; set; }

    }
}