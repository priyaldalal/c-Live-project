﻿using INMS.BAL;
using INMS.DAL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace INMS.BLL
{
    public class BLL_CAT
    {
        public string ManageUser(BAL_CAT objBal)
        {
            DAL_CAT objDal = new DAL_CAT();
            return objDal.ManageUser(objBal);
        }
        public DataTable GetALl(BAL_CAT objBal)
        {
            DAL_CAT objDal = new DAL_CAT();
            return objDal.GetALl(objBal);
        }
        public DataTable GETDETAIL(BAL_CAT objBal)
        {
            DAL_CAT objDal = new DAL_CAT();
            return objDal.GETDETAIL(objBal);
        }
        public string UPDATEUSER(BAL_CAT objBal)
        {
            DAL_CAT objDal = new DAL_CAT();
            return objDal.UPDATEUSER(objBal);
        }
       



        //BRAND

        public string BRANDADD(BAL_CAT objBal)
        {
            DAL_CAT objDal = new DAL_CAT(); ;
            return objDal.BRANDADD(objBal);
        }
        public DataTable GETBRANCH(BAL_CAT objBal)
        {
            DAL_CAT objDal = new DAL_CAT(); ;
            return objDal.GETBRANCH(objBal);
        }
        public DataTable BRANCHGETDETAIL(BAL_CAT objBal)
        {
            DAL_CAT objDal = new DAL_CAT(); ;
            return objDal.BRANCHGETDETAIL(objBal);
        }
       
    }
}