﻿using INMS.BAL;
using INMS.DAL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace INMS.BLL
{
    public class BLL_R
    {
        public string REGISTER(BAL_R objBal)
        {
            DAL_R objDal = new DAL_R();
            return objDal.REGISTER(objBal);
        }
    }
}