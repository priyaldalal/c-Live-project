﻿using INMS.BAL;
using INMS.DAL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace INMS.BLL
{
    public class BLL_STOCK
    {
        public string ManageUser(BAL_STOCK objBal)
        {
            DAL_STOCK objDal = new DAL_STOCK();
            return objDal.ManageUser(objBal);
        }
        public DataTable GetALl(BAL_STOCK objBal)
        {
            DAL_STOCK objDal = new DAL_STOCK();
            return objDal.GetALl(objBal);
        }
        public DataTable GETDETAIL(BAL_STOCK objBal)
        {
            DAL_STOCK objDal = new DAL_STOCK();
            return objDal.GETDETAIL(objBal);
        }
        public string UPDATEUSER(BAL_STOCK objBal)
        {
            DAL_STOCK objDal = new DAL_STOCK();
            return objDal.UPDATEUSER(objBal);
        }
        public string Delete(BAL_STOCK objBal)
        {
            DAL_STOCK objDal = new DAL_STOCK();
            return objDal.Delete(objBal);
        }
        public DataTable GetPRODUCT(BAL_STOCK objBal)
        {
            DAL_STOCK objDal = new DAL_STOCK();
            return objDal.GetPRODUCT(objBal);
        }
    }
}