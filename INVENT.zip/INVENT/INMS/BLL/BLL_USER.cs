﻿using INMS.BAL;
using INMS.DAL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace INMS.BLL
{
    public class BLL_USER
    {
        public string ManageUser(BAL_USER objBal)
        {
            DAL_USER objDal = new DAL_USER();
            return objDal.ManageUser(objBal);
        }
        public DataTable GetALl(BAL_USER objBal)
        {
            DAL_USER objDal = new DAL_USER();
            return objDal.GetALl(objBal);
        }
        public DataTable GETDETAIL(BAL_USER objBal)
        {
            DAL_USER objDal = new DAL_USER();
            return objDal.GETDETAIL(objBal);
        }
        public string UPDATEUSER(BAL_USER objBal)
        {
            DAL_USER objDal = new DAL_USER();
            return objDal.UPDATEUSER(objBal);
        }
        public DataTable GetData(BAL_USER objBal)
        {
            DAL_USER objDal = new DAL_USER();
            return objDal.GetData(objBal);
        }

    }
}