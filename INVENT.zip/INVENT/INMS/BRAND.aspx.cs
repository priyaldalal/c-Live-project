﻿using INMS.BAL;
using INMS.BLL;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace INMS
{
    public partial class BRAND : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        [System.Web.Services.WebMethod]
        public static string BRANDADD(string BNAME, string BDISCRIPTION)
        {
            string str = "";
            BAL_CAT objBal = new BAL_CAT();
            BLL_CAT objBll = new BLL_CAT();

            objBal.BNAME = BNAME;
            objBal.BDISCRIPTION = BDISCRIPTION;

            str = objBll.BRANDADD(objBal);

            return str;
        }
        

        [System.Web.Services.WebMethod]
        public static string BRANCHGETDETAIL(int BID)
        {
            string str = "";
            BAL_CAT objBal = new BAL_CAT();
            BLL_CAT objBll = new BLL_CAT();

            objBal.BID = BID;
            DataTable dt = objBll.BRANCHGETDETAIL(objBal);

            dt.TableName = "tblData";
            using (StringWriter sw = new StringWriter())
            {
                dt.WriteXml(sw);
                str = sw.ToString();
            }
            return str;
        }

        [System.Web.Services.WebMethod]
        public static string GETBRANCH()
        {
            string str = "";
            BAL_CAT objBal = new BAL_CAT();
            BLL_CAT objBll = new BLL_CAT();

            DataTable dt = objBll.GetALl(objBal);

            dt.TableName = "tblData";
            using (StringWriter sw = new StringWriter())
            {
                dt.WriteXml(sw);
                str = sw.ToString();
            }
            return str;
        }
        //[System.Web.Services.WebMethod]
        //public static string UPDATEUSER(int CID, string CNAME)
        //{
        //    string str = "";
        //    BAL_CAT objBal = new BAL_CAT();
        //    BLL_CAT objBll = new BLL_CAT();

        //    objBal.CID = CID;
        //    objBal.CNAME = CNAME;

        //    str = objBll.UPDATEUSER(objBal);

        //    return str;
        //}
    }
}